var app2 =
angular.module("MiFirstApp", []);
app.controller("serviciosController", ["$scope", function($scope){
    $scope.apellido = "Alonso";
    
}]);
